<?php
/**
 * Certifications Module Loader
 * 
 * This file loads the Reports and Notifications modules.
 */

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

// Include Reports module
$reports_file = __DIR__ . '/reports.php';
if (file_exists($reports_file)) {
    require_once $reports_file;
}

// Include Reports module
$reports_file = __DIR__ . '/notifications.php';
if (file_exists($reports_file)) {
    require_once $reports_file;
}
  